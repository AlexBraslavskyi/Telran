package telran.expressions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

public class BracketsChecker {

	HashMap<String, String> closeOpenBrackets = new HashMap<>();
	String[][] bracketsData;
	Set<String> openBrackets = new TreeSet<>();

	public BracketsChecker(String[][] bracketsData) {
		this.bracketsData = bracketsData;
		for (String[] brackets : bracketsData) {
			closeOpenBrackets.put(brackets[1], brackets[0]);
			openBrackets.add(brackets[0]);
		}

	}

	public boolean bracketsCheck(String expression) {
		String[] brackets = getBrackets(expression);

		return check(brackets);
	}

	private boolean check(String[] brackets) {

		Stack<String> stackBrackets = new Stack<>();
		for (String bracket : brackets) {
			if (openBrackets.contains(bracket)) {
				stackBrackets.push(bracket);
			} else {
				if (stackBrackets.isEmpty()) {
					return false;
				}
				if (closeOpenBrackets.get(bracket).equals(stackBrackets.peek())) {
					stackBrackets.pop();
				} else {
					return false;
				}
			}
		}
		return stackBrackets.isEmpty();
	}

	private String[] getBrackets(String expression) {
		ArrayList<Character> expressionSymbol = new ArrayList<Character>();
		ArrayList<String> listBrackets = new ArrayList<String>();
		ArrayList<String> res = new ArrayList<>();
		String temp = "";
		for (char a : expression.toCharArray()) {
			expressionSymbol.add(a);
		}
		for (String brackets[] : bracketsData) {
			listBrackets.addAll(Arrays.asList(brackets));
		}

		for (String bracket : listBrackets) {
			char[] bracketChar = bracket.toCharArray();
			for (int i = 0; i < bracketChar.length; i++) {
				if (bracketChar.length == 1 && expressionSymbol.contains(bracketChar[i])) {
					res.add(bracketChar[i] + "");
					expressionSymbol.remove(expressionSymbol.indexOf(bracketChar[i]));
				} else if (expressionSymbol.contains(bracketChar[i])) {
					temp = temp + bracketChar[i];
					expressionSymbol.remove(expressionSymbol.indexOf(bracketChar[i]));
					if (i == bracketChar.length - 1) {
						res.add(temp);
						temp = "";
					}
				}
			}
		}

		return res.toArray(new String[0]);
	}

	public boolean parenthesesCheck(String expression) {
		int count = 0;
		for (char sym : expression.toCharArray()) {
			if (sym == '(') {
				count++;
			} else if (sym == ')') {
				count--;
				if (count < 0) {
					return false;
				}
			}
		}
		return count == 0;
	}

}
