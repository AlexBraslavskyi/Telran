package telran.util;

import java.io.File;

public interface FileCopyInterface {
	public void copyFile(File source, File dest) throws Exception;
}
