package telran.security.accounting.controllers;

import static telran.security.accounting.api.ApiConstants.ADD_ACCOUNT;
import static telran.security.accounting.api.ApiConstants.ADD_ROLE;
import static telran.security.accounting.api.ApiConstants.GET_ACCOUNT;
import static telran.security.accounting.api.ApiConstants.GET_ACTIVATED_ACCOUNTS;
import static telran.security.accounting.api.ApiConstants.REMOVE_ACCOUNT;
import static telran.security.accounting.api.ApiConstants.REMOVE_ROLE;
import static telran.security.accounting.api.ApiConstants.UPDATE_PASSWORD;
import static telran.security.accounting.api.ApiConstants.USERNAME_PARAM;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import telran.security.accounting.dto.AccountPassword;
import telran.security.accounting.dto.AccountRequest;
import telran.security.accounting.dto.AccountResponse;
import telran.security.accounting.dto.AccountRole;
import telran.security.accounting.service.AccountingManagement;

@RestController
@Validated
public class AccountingManagementController {
@Autowired
AccountingManagement accountingService;
@GetMapping(value = GET_ACCOUNT)
AccountResponse getAccount(@RequestParam(name = USERNAME_PARAM) @NotEmpty String username) {
	return accountingService.getAccount(username);
}

@GetMapping(value = GET_ACTIVATED_ACCOUNTS)
List<AccountResponse> getActivatedAccounts() {
	return accountingService.getActivatedAccounts();
}
@PostMapping(value = ADD_ACCOUNT)
AccountResponse addAccount(@RequestBody @Valid AccountRequest account) {
	return accountingService.addAccount(account);
}
@DeleteMapping(value = REMOVE_ACCOUNT)
void deleteAccount(@RequestParam(name = USERNAME_PARAM)@NotEmpty String username) {
	accountingService.deleteAccount(username);
}
@PutMapping(value = ADD_ROLE)
AccountResponse addRole(@RequestBody @Valid AccountRole accountRole) {
	return accountingService.addRole(accountRole.username, accountRole.role);
}
@PutMapping(value = REMOVE_ROLE)
AccountResponse removeRole(@RequestBody @Valid AccountRole accountRole) {
	return accountingService.removeRole(accountRole.username, accountRole.role);
}
@PutMapping(value = UPDATE_PASSWORD)
AccountResponse updatePassword(@RequestBody @Valid AccountPassword accountPassword) {
	return accountingService.updatePassword(accountPassword.username,
			accountPassword.password);
}
}
