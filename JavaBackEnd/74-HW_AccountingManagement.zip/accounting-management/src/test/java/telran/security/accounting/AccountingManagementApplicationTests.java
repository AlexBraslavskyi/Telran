package telran.security.accounting;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static telran.security.accounting.api.ApiConstants.ADD_ACCOUNT;
import static telran.security.accounting.api.ApiConstants.GET_ACCOUNT;
import static telran.security.accounting.api.ApiConstants.GET_ACTIVATED_ACCOUNTS;
import static telran.security.accounting.api.ApiConstants.REMOVE_ACCOUNT;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.data.mongo.AutoConfigureDataMongo;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.reactive.server.WebTestClient;

import telran.security.accounting.dto.AccountRequest;
import telran.security.accounting.dto.AccountResponse;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@TestMethodOrder(OrderAnnotation.class)
@EnableAutoConfiguration
@AutoConfigureDataMongo
class AccountingManagementApplicationTests {
	private static final String MOSHE = "?username=moshe";

	@Autowired
	WebTestClient webClient;

	String[] roles = new String[] {};
	AccountRequest moshe;

	@BeforeEach
	void reset() {
		moshe = new AccountRequest("moshe", "12345.com", roles, 999);
		roles = new String[] { "ROLE_USER", "ROLE_ADMIN" };
	}

	@Test
	@WithMockUser(username = "admin", roles = { "ADMIN" })
	@Order(1)
	void addAccount() {
		AccountResponse data = webClient.post().uri(ADD_ACCOUNT)
				.contentType(MediaType.APPLICATION_JSON).bodyValue(moshe).exchange()
				.expectStatus().isOk()
				.expectBody(AccountResponse.class).returnResult().getResponseBody();

		assertEquals(data.username, moshe.username);
		assertArrayEquals(data.roles, moshe.roles);

		webClient.post().uri(ADD_ACCOUNT).contentType(MediaType.APPLICATION_JSON)
				.bodyValue(new AccountRequest(null, "12345.com", roles, 100)).exchange().expectStatus()
				.isBadRequest();
		webClient.post().uri(ADD_ACCOUNT).contentType(MediaType.APPLICATION_JSON)
				.bodyValue(new AccountRequest("Sara", "1237", roles, 100)).exchange().expectStatus().isBadRequest();
	}

	@Test
	@WithMockUser(username = "admin", roles = { "ADMIN" })
	@Order(2)
	void getAccount() {
		AccountResponse expected = webClient.get().uri(GET_ACCOUNT + MOSHE).exchange().expectBody(AccountResponse.class)
				.returnResult().getResponseBody();
		assertEquals(expected.username, moshe.username);
		assertArrayEquals(expected.roles, moshe.roles);
	}
	@Test
	@WithMockUser(username = "admin", roles = { "ADMIN" })
	@Order(2)
	void getActivatedAccounts() {
		AccountResponse[] expected = webClient.get().uri(GET_ACTIVATED_ACCOUNTS).exchange().expectBody(AccountResponse[].class)
				.returnResult().getResponseBody();
		assertEquals(1, expected.length);
		assertEquals(expected[0],  webClient.get().uri(GET_ACCOUNT + MOSHE).exchange().expectBody(AccountResponse.class)
				.returnResult().getResponseBody());
	}

	@Test
	@WithMockUser(username = "admin", roles = { "ADMIN" })
	@Order(3)
	void updatePassword() {
//TODO
	}

	@Test
	@WithMockUser(username = "admin", roles = { "ADMIN" })
	@Order(4)
	void addRole() {
//TODO
	}

	@Test
	@WithMockUser(username = "admin", roles = { "ADMIN" })
	@Order(5)
	void deleteRole() {

//		TODO
	}

	@Test
	@WithMockUser(username = "admin", roles = { "ADMIN" })
	@Order(6)
	void deleteAccount() {
		webClient.delete().uri(REMOVE_ACCOUNT + MOSHE).exchange().expectStatus().isOk();
		webClient.get().uri(REMOVE_ACCOUNT + MOSHE).exchange().expectStatus().isOk().equals(null);
	}

}
