package telran.exceptions;

public class RangeException extends RuntimeException {

	
	public RangeException(String message){
		super(); 
	}
}
