package telran.spring.jpa.dto;

public interface StudentMarksCount {

	String getName();
	Long getMarksCount();
}
