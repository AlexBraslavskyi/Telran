package telran.utils;

public class MemoryService {

	/**
	 * 
	 * @return maximal size of memory in bytes that may be allocated using the
	 *         operator new
	 */
	public static int getMaxNewMemory() {
		int maxSize = Integer.MAX_VALUE;
		int left = 0;
		int middle = 0;
		while (left<=maxSize) {
			middle = left/2 + maxSize/2;
			try {
				byte ar[] = new byte[middle];
				ar = null;
				left = middle + 1;
					} catch (Throwable q) {
						maxSize = middle - 1;
					}
		}
		return middle;
	}
}
