# logs-bugs-reporter
Project for logs managment and automatic opening bugs
