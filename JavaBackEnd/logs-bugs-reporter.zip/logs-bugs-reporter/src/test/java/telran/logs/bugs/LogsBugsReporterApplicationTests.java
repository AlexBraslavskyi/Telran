package telran.logs.bugs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogsBugsReporterApplicationTests {

	@Test
	void contextLoads() {
	}

}
