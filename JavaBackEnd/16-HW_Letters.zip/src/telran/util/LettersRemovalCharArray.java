package telran.util;

import java.util.Arrays;

public class LettersRemovalCharArray implements LettersRemovalInterface {

	@Override
	public String removeLetter(String strings, char letter) {

		char[] charArray = strings.toCharArray();
		int j = 0;
		char newArrayChar [] = new char [charArray.length];
		for (int i = 0; i < charArray.length; i++) {
			if (charArray[i] != letter) {
				newArrayChar[j] = charArray[i];
				j++;
			}
		}
	 return new String(Arrays.copyOf(newArrayChar, j));
	}

}
