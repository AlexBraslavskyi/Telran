package telran.util;

public class LettersRemovalStringBuilder implements LettersRemovalInterface {

	@Override
	public String removeLetter(String strings, char letter) {
		char [] charArray = strings.toCharArray();
		StringBuilder builder = new StringBuilder(charArray[0]);
		for(int i = 0; i < charArray.length; i++) {
			if(charArray[i] != letter) {
			builder.append(charArray[i]);
		}	
	}
	return builder.toString();
}
}