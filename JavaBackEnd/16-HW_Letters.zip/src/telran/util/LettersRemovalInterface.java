package telran.util;

public interface LettersRemovalInterface {
	public String removeLetter(String strings, char letter);
}
