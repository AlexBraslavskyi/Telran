package telran.util;


public class LettersRemovalReplaceAll implements LettersRemovalInterface {

	@Override
	public String removeLetter(String strings, char letter) {
		String strLetter = "" + letter;
		
	  return strings.replaceAll(strLetter, "");
	}

}
