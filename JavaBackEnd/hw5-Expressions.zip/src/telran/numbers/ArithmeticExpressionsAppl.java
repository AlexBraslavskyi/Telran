package telran.numbers;

import java.util.Scanner;
import static telran.numbers.ArithmeticExpressions.compute;



public class ArithmeticExpressionsAppl {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		while(true) {
			System.out.println("********************************");
			System.out.println("Enter expression, or type \"exit\"");
			String expInput = scanner.nextLine();
			
			if(expInput.equals("exit")) {
				break;
			}		
			double result = compute(expInput);
			System.out.println("Result = "+result);
			

		}
	}
}
