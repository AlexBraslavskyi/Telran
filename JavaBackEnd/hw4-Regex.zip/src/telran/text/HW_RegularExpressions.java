package telran.text;

public class HW_RegularExpressions {
	public static String israelMobilePhone() {
		
		String regex = "([+]972|0)-?5(0|[2-8])-?(\\d-?){6}\\d";
		return regex;
		
	}
public static String emailAddress(){
		
		String regex = "[a-zA-Z0-9_&#$%!'~{}|?^+=*/`-]+[.]?[a-zA-Z0-9_&#$%!'~{}|?^+=*/`-]+@[a-z]-?+[a-z]+(\\.[a-z]-?+[a-z]+){1,3}";
		return regex;
		
	}

}
