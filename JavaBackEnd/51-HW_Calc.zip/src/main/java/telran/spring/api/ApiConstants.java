package telran.spring.api;

public interface ApiConstants {

	String CALCULATOR = "/calculator";
	String ADD = "add";
	String SUB = "sub";
	String DIV = "div";
	String MULT = "mult";
	String POW = "pow";
	String PER = "per";
}
