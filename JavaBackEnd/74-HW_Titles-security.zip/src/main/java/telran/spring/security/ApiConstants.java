package telran.spring.security;

public interface ApiConstants {
 String URL = "titles/{id}";
 String ID = "id";
}
