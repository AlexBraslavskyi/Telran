package telran.spring.security;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.client.RestTemplate;

import telran.security.accounting.dto.AccountResponse;

@Configuration
public class SecurityConfiguration {
	static RestTemplate restTemplate = new RestTemplate();
	@Value("${app-password-admin}")
	String passwordAdmin;
	@Value("${app-user-name}")
	String userName;
	@Value("${app-user-password}")
	String userPassword;
	@Value("${app-path}")
	String path;
	@Value("${app-default-user:admin}")
	String defaultUser;
	@Value("${app-default-user-role:ROLE_ADMIN}")
	String defaultUserRole;
	private static String getAuthToken(String username, String password) {
		String rowText = username + ":" + password;
		String token = "Basic " + Base64.getEncoder().encodeToString(rowText.getBytes());
		return token;
	}
	
	@Bean
	MapReactiveUserDetailsService getMapDetails() {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", getAuthToken(userName, userPassword));
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		ResponseEntity<AccountResponse[]> response = restTemplate.exchange(path, HttpMethod.GET, requestEntity, AccountResponse[].class);
		List<UserDetails> usersList = new ArrayList<>();
		usersList.add(new User(defaultUser, passwordAdmin, AuthorityUtils.createAuthorityList(defaultUserRole)));
		if (response.getBody() != null) {
			for (int i = 0; i < response.getBody().length; i++) {
				
				usersList.add(new User(response.getBody()[i].username, response.getBody()[i].password,
						AuthorityUtils.createAuthorityList(rolesFormat(response.getBody()[i].roles))));
				System.out.println(usersList.get(i+1));
			}
		}
		return new MapReactiveUserDetailsService(usersList);
	}

	@Bean
	SecurityWebFilterChain securityFiltersChain(ServerHttpSecurity httpSecurity) {
		SecurityWebFilterChain securityFiltersChain = httpSecurity.csrf()
				.disable().httpBasic()
				.and().authorizeExchange().pathMatchers(HttpMethod.GET)
				.hasAnyRole("USER","ADMIN").anyExchange()
				.hasRole("ADMIN").and().
				build();
		return securityFiltersChain;
	}
	
	private String[] rolesFormat(String[] roles) {
		return Stream.of(roles).map(role -> "ROLE_"+role.toUpperCase()).toArray(String[]::new);
	}
}
