package telran.employees.dto;

public enum ReturnCodes {
EMPLOYEE_NOT_FOUND, EMPLOYEE_ALREADY_EXIST, OK;
}
