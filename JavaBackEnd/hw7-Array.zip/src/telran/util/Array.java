package telran.util;

import java.util.Arrays;

public class Array<T> {
	
	private T [] array;
	
	private int size;//blue  = 0
	private static int defaultCapacity = 16;
	@SuppressWarnings("unchecked")
	public Array(int capacity) {
		array = (T[]) new Object[capacity];
	}
	public Array() {
		this(defaultCapacity);
	}
	public void add(T obj) {
		if(size == array.length) {
			reallocate();
		}
		array[size++] = obj;
		
	}
	private void reallocate() {
		array = Arrays.copyOf(array, array.length * 2);
	}
	
	
	//return element at given index
	//if index<0 or index>=size return null
	
	public T get(int index) {
		if(index < 0 || index >= size) {
			return null;
		}
		return array[index];
	}
	public int size() {
		return size;
	}
	
	public boolean add(int index, T obj) {
		System.out.println("Array - " + Arrays.deepToString(array));
		System.out.println("Add - " + obj + " Index - " + index);
		if(index >= 0 && index <= size - 1) {
			if(size == array.length) {
				reallocate();
			}
			System.arraycopy(array, 0, array, 0, index);
			T temp = array[index];
			System.arraycopy(array, index + 1, array, index + 2,array.length - index - 2);
			array[index] = obj;
			array[index + 1] = temp;
			size ++;
		System.out.println("Result - " + Arrays.deepToString(array));
		System.out.println("***********************************************************");
			return true;
		}else {
			return false;
		}
		
	}
	
	public T remove(int index) {
		System.out.println("Array - " + Arrays.deepToString(array));
		System.out.println("Remove index - " + index);
		if(index >= 0&& index < size - 1) {
			System.arraycopy(array, 0, array, 0, index);
			System.arraycopy(array, index + 1, array, index, array.length - index - 1);
			array[array.length - 1] = null;
			size --;
		System.out.println("Result - " + Arrays.deepToString(array));
		System.out.println("************************************************************");
			return array[index];
		}else {
		
		return null;
		
	}
}
}
