package telran.spring.jpa.dto;

public interface IntervalMarks {

	int getMin();
	int getMax();
	Long getMarksCount();
}
