package telran.person.dto;

import java.time.LocalDate;

public class Child extends Person {
	String garden;
	
	public Child() {
		
	}
	public Child(int id, Address adress, String name, LocalDate birthDate, String garden) {
		super(id, adress, name, birthDate);
		this.garden = garden;
	}


	@Override
	public String toString() {
		return "Child [garden=" + garden + ", id=" + id + ", adress=" + adress + ", name=" + name + ", birthDate="
				+ birthDate + "]";
	}
	public String getGarden() {
		return garden;
	}
	public void setGarden(String garden) {
		this.garden = garden;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



}
