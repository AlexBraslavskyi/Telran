package telran.util;

import java.util.function.Predicate;

public class PredicateRetainAll<T> implements Predicate<T> {
	IndexedList <T> pattern;
	public PredicateRetainAll(IndexedList <T> pattern) {
		this.pattern = pattern;
	}
	@Override
	public boolean test(T t) {

		return !pattern.contains(t);
	}

}
