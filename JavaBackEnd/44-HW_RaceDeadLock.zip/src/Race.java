

public class Race {
public  int minSleep;
public  int maxSleep;
public int distance;
public int photoFinish = 0;
public Race(int minSleep, int maxSleep, int distance) {
	super();
	this.minSleep = minSleep;
	this.maxSleep = maxSleep;
	this.distance = distance;
}

}
